﻿using System;
using System.Reflection.Metadata;
using System.IO;

namespace PII_Game_Of_Life
{
    class Program
    {
        static void Main(string[] args)
        {
            Generador generador= new Generador();
            string urlArchivo = "C:\\Users\\leand\\OneDrive\\Escritorio\\Programación II\\PII_Game_of_Life\\PII_Game_of_Life-master\\assets\\board.txt";
            bool[,] Tablero = generador.LeerArchivo(urlArchivo);
            Tablero tablero = new Tablero();

            while(true){
                Tablero = tablero.ImprimirTablero(Tablero);
            }
        }
    }
}
