using System.Threading;
using PII_Game_Of_Life;

public class Tablero{

    public bool[,] ImprimirTablero(bool[,] b){
        ConsolePrinter c = new ConsolePrinter();
        Logica l = new Logica();
        c.Imprimir(b);
        b = l.ApplyRules(b);
        Thread.Sleep(300);
        return b;
    }
}


